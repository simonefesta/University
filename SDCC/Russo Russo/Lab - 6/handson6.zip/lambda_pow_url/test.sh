#!/bin/bash

URL="https://ip77y263v75ctscdcsnj6mzjge0wcsxk.lambda-url.eu-central-1.on.aws/"

x=3
y=3

echo "pow($x,$y) =" $(curl -s "$URL?x=$x&y=$y")

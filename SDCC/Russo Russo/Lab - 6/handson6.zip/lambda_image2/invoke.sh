ARN="arn:aws:states:eu-central-1:227415535924:stateMachine:my-state-machine"
imageUrl="$1"

if [[ "x$imageUrl" == "x" ]]; then
	echo "Usage: test.sh <URL>"
	exit 1
fi

aws stepfunctions start-execution --state-machine-arn "$ARN" \
    --input "{\"image\" : \"$imageUrl\", \"bucket\": \"sdcc2223\"}"

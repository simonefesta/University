
function compute() {
	disableButton();
	setTimeout(enableButton, 4000); // just to be sure

	var $form = $("#conf")
	var $inputs = $form.find("input, select, button, range");

	var confX = $("#x-range").val();
	var confY = $("#y-range").val();

	// Let's disable the inputs for the duration of the Ajax request.
	$inputs.prop("disabled", true);

	// Fire off the request 
	request = $.ajax({
		url: "https://a8noa7jg5k.execute-api.eu-central-1.amazonaws.com/test/pow",
		data: {
			x: confX,
			y: confY
		},
		type: "get",
	});

	// Callback handler that will be called on success
	request.done(function (response, textStatus, jqXHR){
		onComplete(response);
	});

	// Callback handler that will be called on failure
	request.fail(function (jqXHR, textStatus, errorThrown){
		// Log the error to the console
		console.error(
			"The following error occurred: "+
			textStatus, errorThrown
		);
		onFailure();
	});

}


function onComplete(response) {
	console.log(response)
	var result = parseFloat(response);
	$("#results-box").show();

	$("#result").html(result)
	
	var $form = $("#conf")
	var $inputs = $form.find("input, select, button, range");
	$inputs.prop("disabled", false);
	enableButton();
}

function onFailure() {
	$("#results-box").hide();
	$("#resultsh").html("Computation failed :(")

	var $form = $("#conf")
	var $inputs = $form.find("input, select, button, range");
	$inputs.prop("disabled", false);
	enableButton();
}

function disableButton() {
	$("#run").prop("disabled", true)
	$("#run").html("...running...");
}

function enableButton() {
	$("#run").prop("disabled", false)
	$("#run").html("Run");
}

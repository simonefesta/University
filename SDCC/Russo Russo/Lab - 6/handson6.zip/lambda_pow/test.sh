#!/bin/bash

BASEURL="https://a8noa7jg5k.execute-api.eu-central-1.amazonaws.com/test"

x=3
y=4

echo "pow($x,$y) =" $(curl -s "$BASEURL/pow?x=$x&y=$y")

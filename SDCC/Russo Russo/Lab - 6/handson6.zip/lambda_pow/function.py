import json

def my_handler(event, context):
    response = {}
    response["statusCode"] = 200
    result = None

    params = event["queryStringParameters"]

    if params != None and "x" in params and "y" in params:
        try:
            x = int(params['x'])
            y = int(params['y'])
            result = x**y
            print("{}**{} = {}".format(x, y, result))
            response["body"] = json.dumps(result)
        except:
            print("ERR: {}".format(event))

    response["headers"] = {\
            'Access-Control-Allow-Headers': 'Content-Type',\
            'Access-Control-Allow-Origin': '*',\
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'\
        }

    return response
